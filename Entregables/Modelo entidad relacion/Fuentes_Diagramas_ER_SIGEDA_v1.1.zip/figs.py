# Genera las figuras ER y relacionales de SIGEDA v1.1 (Graphviz DOT -> PNG/SVG).
import subprocess, os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/er11/figs'
NAVY = '#0B2140'
LINE = '#2B3A55'
BG = '#F7F9FC'
GRAY = '#6B7280'
FONT = 'Carlito'
DOUBLE = f'{LINE}:invis:{LINE}'


def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


# ---------- ER ----------
def attr_row(a):
    """a = (texto, estilo, nota). estilo: id | partial | derived | plain"""
    txt, st, note = (a + (None, None))[:3] if isinstance(a, tuple) else (a, 'plain', None)
    st = st or 'plain'
    t = esc(txt)
    n = f' <FONT POINT-SIZE="8" COLOR="{GRAY}">{esc(note)}</FONT>' if note else ''
    if st == 'id':
        return f'<TR><TD ALIGN="LEFT" BALIGN="LEFT"><U>{t}</U>{n}</TD></TR>'
    if st == 'partial':
        return (f'<TR><TD ALIGN="LEFT"><TABLE ALIGN="LEFT" BORDER="0" CELLSPACING="0" CELLPADDING="0"><TR>'
                f'<TD ALIGN="LEFT" SIDES="B" BORDER="1" STYLE="dashed" COLOR="{NAVY}">{t}</TD><TD ALIGN="LEFT">{n}</TD></TR></TABLE></TD></TR>')
    if st == 'derived':
        return f'<TR><TD ALIGN="LEFT"><I>/{t}</I>{n}</TD></TR>'
    return f'<TR><TD ALIGN="LEFT">{t}{n}</TD></TR>'


def entity(name, attrs=None, weak=False, ref=False):
    rows = ''.join(attr_row(a) for a in (attrs or []))
    if ref:
        head = f'<TR><TD BGCOLOR="#E5E9F0" CELLPADDING="5"><B>{esc(name)}</B></TD></TR>'
        lab = f'<<TABLE BORDER="1" STYLE="dashed" COLOR="#8A97AB" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3">{head}</TABLE>>'
        return f'[shape=plain label={lab}]'
    head = f'<TR><TD BGCOLOR="{NAVY}" CELLPADDING="5"><FONT COLOR="white"><B>{esc(name)}</B></FONT></TD></TR>'
    lab = (f'<<TABLE BORDER="1" COLOR="{NAVY}" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="{BG}">'
           f'{head}{rows}</TABLE>>')
    if weak:
        return f'[shape=box peripheries=1 color="{NAVY}" penwidth=1.4 margin="0.03,0.03" label={lab}]'
    return f'[shape=plain label={lab}]'


def rel(a, b, ta, hb, label='', ident=False, extra=''):
    col = DOUBLE if ident else LINE
    lab = f' label=<<I>{"<BR/>".join(esc(x) for x in label.split("|"))}</I>>' if label else ''
    return (f'{a} -> {b} [dir=both arrowtail={ta} arrowhead={hb} color="{col}" penwidth=1.3 '
            f'arrowsize=0.9{lab} {extra}];')


def graph(name, body, rankdir='TB', extra=''):
    return (f'digraph "{name}" {{\n rankdir={rankdir}; bgcolor="white"; pad=0.2; nodesep=0.55; ranksep=0.6; {extra}\n'
            f' node [fontname="{FONT}" fontsize=11];\n edge [fontname="{FONT}" fontsize=10 fontcolor="#1F2937"];\n'
            f'{body}\n}}\n')


def render(fname, src, dpi=220):
    p = os.path.join(OUT, fname)
    open(p + '.dot', 'w').write(src)
    for fmt in ('png', 'svg'):
        args = ['dot', f'-T{fmt}', p + '.dot', '-o', f'{p}.{fmt}']
        if fmt == 'png':
            args.insert(1, f'-Gdpi={dpi}')
        subprocess.run(args, check=True)


# Atributos ER
A_SECTOR = [('nombre', 'id')]
A_ABONADO = [('numero_paja', 'id'), 'tipo_abonado', 'estado', ('fecha_baja', 'plain', '(0..1)'),
             ('titular_vigente', 'derived'), ('estado_completitud', 'derived')]
A_PERSONA = [('id_persona', 'id'), 'nombre', ('identificacion', 'plain', '[tipo + número] (0..1)')]
A_GRUPO = [('nombre', 'id'), 'obligatoriedad']
A_TIPO = [('nombre', 'id'), 'prioridad', ('obligatoriedad', 'plain', '(0..1)'), 'es_exigido_a_cotitulares']
A_DOC = [('id_documento', 'id'), ('nombre_identificador', 'plain', '(0..1)'), 'estado',
         ('motivo_anulacion', 'plain', '(0..1)'), ('fecha_anulacion', 'plain', '(0..1)'), ('version_vigente', 'derived')]
A_VER = [('numero_version', 'partial', '(clave parcial)'), 'nombre_original', 'ruta_archivo', 'formato', 'tamano_bytes',
         'fecha_documento', 'fecha_carga', 'hash_sha256']
A_CUENTA = [('usuario', 'id'), 'hash_contrasena', 'perfil', 'intentos_fallidos', ('bloqueada_hasta', 'plain', '(0..1)'),
            'es_contrasena_temporal']
A_RESP = [('id_respaldo', 'id'), 'fecha_hora', 'tipo', ('estado', 'plain', '(derivado que se guarda)'),
          ('nombre_paquete', 'plain', '(0..1)'), ('hash_sha256', 'plain', '(0..1)'), ('tamano_bytes', 'plain', '(0..1)')]
A_COPIA = [('destino', 'partial', '(clave parcial)'), 'estado', ('fecha_hora_verificacion', 'plain', '(0..1)')]
A_BIT = [('id_registro_bitacora', 'id'), 'fecha_hora', ('accion', 'plain', '(discriminador)'), 'elemento_afectado', 'origen']
A_MOD = [('campo_modificado', 'partial', '(clave parcial)'), ('valor_anterior', 'plain', '(0..1)'),
         ('valor_nuevo', 'plain', '(0..1)')]
A_REST = ['nombre_paquete', 'fecha_respaldo_restaurado']

VINC_ATTRS = ('<<TABLE BORDER="1" STYLE="rounded" COLOR="#8A97AB" CELLBORDER="0" CELLSPACING="0" CELLPADDING="2" BGCOLOR="white">'
              '<TR><TD ALIGN="LEFT">rol</TD></TR><TR><TD ALIGN="LEFT">fecha_inicio</TD></TR>'
              f'<TR><TD ALIGN="LEFT">fecha_fin <FONT POINT-SIZE="8" COLOR="{GRAY}">(0..1)</FONT></TD></TR>'
              '<TR><TD ALIGN="LEFT"><I>/es_vigente</I></TD></TR></TABLE>>')
DIAMOND = f'[shape=diamond style=filled fillcolor="#DCE3ED" color="{LINE}" label=<<I>se_vincula_con</I>> fontsize=10 width=1.9 height=0.95]'
FUS_NODE = f'[shape=diamond style=filled fillcolor="#DCE3ED" color="{LINE}" label=<<I>se_fusiona_en</I>> fontsize=10 width=1.6 height=0.8]'
def fusion_edges(p='Persona'):
    return [f'fus {FUS_NODE};',
            f'{p} -> fus [dir=back arrowtail=crowodot color="{LINE}" penwidth=1.2 label=<<FONT POINT-SIZE="9"><I>duplicada</I></FONT>>];',
            f'fus -> {p} [arrowhead=teeodot color="{LINE}" penwidth=1.2 label=<<FONT POINT-SIZE="9"><I>la que queda</I></FONT>>];']
GEN_NOTE = (f'[shape=plaintext fontsize=10 label=<<I>Especialización parcial y disjunta.<BR/>'
            f'Discriminador: accion = RESTAURACION.</I>>]')


def er_general():
    b = []
    for n, lab, w in [('Sector', 'Sector', 0), ('Abonado', 'Abonado', 0), ('Persona', 'Persona', 0),
                      ('GrupoAlternativas', 'GrupoAlternativas', 0), ('TipoDocumento', 'TipoDocumento', 0),
                      ('Documento', 'Documento', 0), ('VersionDocumento', 'VersionDocumento', 1),
                      ('Cuenta', 'Cuenta', 0), ('RegistroBitacora', 'RegistroBitacora', 0),
                      ('RegistroModificacion', 'RegistroModificacion', 1), ('RegistroRestauracion', 'RegistroRestauracion', 0),
                      ('Respaldo', 'Respaldo', 0), ('CopiaRespaldo', 'CopiaRespaldo', 1)]:
        b.append(f'{n} {entity(lab, weak=bool(w))};')
    b.append(f'vinc {DIAMOND};')
    b += [
        rel('Sector', 'Abonado', 'teeodot', 'crowodot', 'ubica_en'),
        f'Abonado -> vinc [dir=back arrowtail=crowtee color="{LINE}" penwidth=1.3];',
        f'vinc -> Persona [arrowhead=crowtee color="{LINE}" penwidth=1.3];',
        rel('Abonado', 'Documento', 'teetee', 'crowodot', 'tiene_documentos'),
        rel('Persona', 'Documento', 'teeodot', 'crowodot', 'aporta'),
    ] + fusion_edges() + [
        rel('GrupoAlternativas', 'TipoDocumento', 'teeodot', 'crowtee', 'agrupa (2..*)'),
        rel('TipoDocumento', 'Documento', 'teetee', 'crowodot', 'clasifica'),
        rel('Documento', 'VersionDocumento', 'teetee', 'crowtee', 'contiene', ident=True),
        rel('Cuenta', 'RegistroBitacora', 'teeodot', 'crowodot', 'realiza'),
        rel('Abonado', 'RegistroBitacora', 'teeodot', 'crowodot', 'afecta_a', extra='constraint=false'),
        rel('Cuenta', 'Respaldo', 'teeodot', 'crowodot', 'inicia'),
        rel('Respaldo', 'CopiaRespaldo', 'teetee', 'crowodot', 'tiene_copias (0..2)', ident=True),
        rel('RegistroBitacora', 'RegistroModificacion', 'teetee', 'crowodot', 'detalla', ident=True),
        f'RegistroRestauracion -> RegistroBitacora [arrowhead=empty arrowsize=1.4 color="{LINE}" label=<<I>es_un</I>> dir=forward];',
        '{rank=same; Sector; GrupoAlternativas; Cuenta;}',
        '{rank=same; Abonado; TipoDocumento; RegistroRestauracion; Respaldo;}',
        '{rank=same; RegistroBitacora; CopiaRespaldo;}',
    ]
    return graph('ER_General', '\n '.join(b), extra='ranksep=0.7; nodesep=0.45;')


def er_abonados():
    b = [f'Sector {entity("Sector", A_SECTOR)};', f'Abonado {entity("Abonado", A_ABONADO)};',
         f'Persona {entity("Persona", A_PERSONA)};', f'vinc {DIAMOND};',
         f'vattr [shape=plain label={VINC_ATTRS}];',
         rel('Sector', 'Abonado', 'teeodot', 'crowodot', 'ubica_en'),
         f'Abonado -> vinc [dir=back arrowtail=crowtee color="{LINE}" penwidth=1.3];',
         f'vinc -> Persona [arrowhead=crowtee color="{LINE}" penwidth=1.3];',
         f'vinc -> vattr [arrowhead=none style=dashed color="#8A97AB" constraint=false];',
         '{rank=same; vinc; vattr;}',
         ] + fusion_edges() + ['{rank=same; Persona; fus;}']
    return graph('ER_Abonados', '\n '.join(b))


def er_documentos():
    b = [f'GrupoAlternativas {entity("GrupoAlternativas", A_GRUPO)};', f'TipoDocumento {entity("TipoDocumento", A_TIPO)};',
         f'Abonado {entity("Abonado", ref=True)};', f'Persona {entity("Persona", ref=True)};',
         f'Documento {entity("Documento", A_DOC)};', f'VersionDocumento {entity("VersionDocumento", A_VER, weak=True)};',
         rel('GrupoAlternativas', 'TipoDocumento', 'teeodot', 'crowtee', 'agrupa|2..* tipos por grupo'),
         rel('TipoDocumento', 'Documento', 'teetee', 'crowodot', 'clasifica'),
         rel('Abonado', 'Documento', 'teetee', 'crowodot', 'tiene_documentos'),
         rel('Persona', 'Documento', 'teeodot', 'crowodot', 'aporta'),
         rel('Documento', 'VersionDocumento', 'teetee', 'crowtee', 'contiene|(identificadora)', ident=True),
         '{rank=same; TipoDocumento; Abonado; Persona;}']
    return graph('ER_Documentos', '\n '.join(b))


def er_seguridad():
    b = [f'Cuenta {entity("Cuenta", A_CUENTA)};', f'Abonado {entity("Abonado", ref=True)};',
         f'Respaldo {entity("Respaldo", A_RESP)};', f'CopiaRespaldo {entity("CopiaRespaldo", A_COPIA, weak=True)};',
         f'RegistroBitacora {entity("RegistroBitacora", A_BIT)};',
         f'RegistroModificacion {entity("RegistroModificacion", A_MOD, weak=True)};',
         f'RegistroRestauracion {entity("RegistroRestauracion", A_REST)};',
         rel('Cuenta', 'Respaldo', 'teeodot', 'crowodot', 'inicia'),
         rel('Cuenta', 'RegistroBitacora', 'teeodot', 'crowodot', 'realiza'),
         rel('Abonado', 'RegistroBitacora', 'teeodot', 'crowodot', 'afecta_a'),
         rel('Respaldo', 'CopiaRespaldo', 'teetee', 'crowodot', 'tiene_copias|(identificadora)|0..2 copias', ident=True),
         rel('RegistroBitacora', 'RegistroModificacion', 'teetee', 'crowodot', 'detalla (identificadora)|1..* si MODIFICACION|o ANULACION', ident=True),
         f'RegistroRestauracion -> RegistroBitacora [dir=forward arrowhead=empty arrowsize=1.5 color="{LINE}" label=<<I>es_un</I>>];',
         '{rank=same; Abonado; Cuenta;}', '{rank=same; Respaldo; RegistroBitacora;}',
         '{rank=same; CopiaRespaldo; RegistroModificacion; RegistroRestauracion;}']
    return graph('ER_Seguridad', '\n '.join(b))


# ---------- Relacional ----------
def table(name, cols, ref=False):
    """cols = (columna, marca, pk:bool)"""
    if ref:
        return entity(name, ref=True)
    rows = ''
    for c, m, pk in cols:
        cc = f'<B>{esc(c)}</B>' if pk else esc(c)
        rows += (f'<TR><TD ALIGN="LEFT">{cc}</TD>' +
                 (f'<TD ALIGN="LEFT"><FONT POINT-SIZE="8" COLOR="{GRAY}">{esc(m)}</FONT></TD></TR>' if m else '<TD> </TD></TR>'))
    head = f'<TR><TD COLSPAN="2" BGCOLOR="{NAVY}" CELLPADDING="5"><FONT COLOR="white"><B>{esc(name)}</B></FONT></TD></TR>'
    lab = (f'<<TABLE BORDER="1" COLOR="{NAVY}" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="{BG}">'
           f'{head}{rows}</TABLE>>')
    return f'[shape=plain label={lab}]'


T = {
    'sector': [('id_sector', 'PK', 1), ('nombre', 'UQ', 0)],
    'abonado': [('id_abonado', 'PK', 1), ('numero_paja', 'UQ', 0), ('id_sector', 'FK→sector · opc.', 0),
                ('tipo_abonado', 'CHECK', 0), ('estado', 'CHECK', 0), ('fecha_baja', 'opc.', 0)],
    'persona': [('id_persona', 'PK', 1), ('nombre', '', 0), ('tipo_identificacion', 'CHECK · opc. · UQ parcial (1)', 0),
                ('identificacion', 'opc. · UQ parcial (1)', 0), ('id_persona_fusionada_en', 'FK→persona · opc.', 0)],
    'vinculo_abonado': [('id_abonado', 'PK · FK→abonado', 1), ('id_persona', 'PK · FK→persona', 1),
                        ('fecha_inicio', 'PK', 1), ('rol', 'CHECK', 0), ('fecha_fin', 'opc.', 0)],
    'grupo_alternativas': [('id_grupo_alternativas', 'PK', 1), ('nombre', 'UQ', 0), ('obligatoriedad', 'CHECK', 0)],
    'tipo_documento': [('id_tipo_documento', 'PK', 1), ('id_grupo_alternativas', 'FK→grupo_alternativas · opc.', 0),
                       ('nombre', 'UQ', 0), ('prioridad', '', 0), ('obligatoriedad', 'CHECK · opc.', 0),
                       ('es_exigido_a_cotitulares', '', 0)],
    'documento': [('id_documento', 'PK', 1), ('id_abonado', 'FK→abonado', 0), ('id_tipo_documento', 'FK→tipo_documento', 0),
                  ('id_persona', 'FK→persona · opc.', 0), ('nombre_identificador', 'opc.', 0), ('estado', 'CHECK', 0),
                  ('motivo_anulacion', 'opc.', 0), ('fecha_anulacion', 'opc.', 0)],
    'version_documento': [('id_documento', 'PK · FK→documento', 1), ('numero_version', 'PK', 1),
                          ('nombre_original', '', 0), ('ruta_archivo', 'UQ', 0), ('formato', 'CHECK', 0),
                          ('tamano_bytes', '', 0), ('fecha_documento', '', 0), ('fecha_carga', '', 0), ('hash_sha256', '', 0)],
    'cuenta': [('id_cuenta', 'PK', 1), ('usuario', 'UQ', 0), ('hash_contrasena', '', 0), ('perfil', 'CHECK', 0),
               ('intentos_fallidos', '', 0), ('bloqueada_hasta', 'opc.', 0), ('es_contrasena_temporal', '', 0)],
    'registro_bitacora': [('id_registro_bitacora', 'PK', 1), ('id_cuenta', 'FK→cuenta · opc.', 0),
                          ('id_abonado', 'ref. lógica→abonado · opc.', 0), ('fecha_hora', '', 0),
                          ('accion', 'CHECK · discriminador', 0), ('elemento_afectado', '', 0), ('origen', 'CHECK', 0)],
    'registro_modificacion': [('id_registro_bitacora', 'PK · FK→registro_bitacora', 1), ('campo_modificado', 'PK', 1),
                              ('valor_anterior', 'opc.', 0), ('valor_nuevo', 'opc.', 0)],
    'registro_restauracion': [('id_registro_bitacora', 'PK · FK→registro_bitacora', 1), ('nombre_paquete', '', 0),
                              ('fecha_respaldo_restaurado', '', 0)],
    'respaldo': [('id_respaldo', 'PK', 1), ('id_cuenta', 'FK→cuenta · opc.', 0), ('fecha_hora', '', 0), ('tipo', 'CHECK', 0),
                 ('estado', 'CHECK · derivado guardado', 0), ('nombre_paquete', 'UQ · opc.', 0), ('hash_sha256', 'opc.', 0),
                 ('tamano_bytes', 'opc.', 0)],
    'copia_respaldo': [('id_respaldo', 'PK · FK→respaldo', 1), ('destino', 'PK · CHECK', 1), ('estado', 'CHECK', 0),
                       ('fecha_hora_verificacion', 'opc.', 0)],
}

# FK: (padre, hijo, extremo padre, extremo hijo)
FKS = [('sector', 'abonado', 'teeodot', 'crowodot'),
       ('abonado', 'vinculo_abonado', 'teetee', 'crowodot'),
       ('persona', 'vinculo_abonado', 'teetee', 'crowodot'),
       ('abonado', 'documento', 'teetee', 'crowodot'),
       ('persona', 'documento', 'teeodot', 'crowodot'),
       ('tipo_documento', 'documento', 'teetee', 'crowodot'),
       ('grupo_alternativas', 'tipo_documento', 'teeodot', 'crowodot'),
       ('documento', 'version_documento', 'teetee', 'crowtee'),
       ('cuenta', 'registro_bitacora', 'teeodot', 'crowodot'),
       ('registro_bitacora', 'registro_modificacion', 'teetee', 'crowodot'),
       ('registro_bitacora', 'registro_restauracion', 'teetee', 'teeodot'),
       ('cuenta', 'respaldo', 'teeodot', 'crowodot'),
       ('respaldo', 'copia_respaldo', 'teetee', 'crowodot')]
SELF = ('persona', 'teeodot', 'crowodot')  # persona.id_persona_fusionada_en -> persona


def simple_table(name):
    return (f'[shape=box style=filled fillcolor="{NAVY}" color="{NAVY}" fontcolor="white" '
            f'label=<<B>{name}</B>> margin="0.2,0.1"]')


def rel_general():
    b = [f'{t} {simple_table(t)};' for t in T]
    for p, c, tp, tc in FKS:
        b.append(f'{p} -> {c} [dir=both arrowtail={tp} arrowhead={tc} color="{LINE}" penwidth=1.2];')
    b.append(f'persona:e -> persona:e [dir=both arrowtail=crowodot arrowhead=teeodot color="{LINE}" penwidth=1.1];')
    b += ['{rank=same; sector; persona; grupo_alternativas; cuenta;}',
          '{rank=same; abonado; tipo_documento; registro_bitacora; respaldo;}',
          '{rank=same; vinculo_abonado; documento; registro_modificacion; registro_restauracion; copia_respaldo;}']
    return graph('Rel_General', '\n '.join(b), extra='nodesep=0.35; ranksep=0.55;')


def rel_detail(name, tables, refs, extra_rank=()):
    b = [f'{t} {table(t, T[t])};' for t in tables]
    b += [f'{r} {table(r, None, ref=True)};' for r in refs]
    allt = set(tables) | set(refs)
    for p, c, tp, tc in FKS:
        if p in allt and c in allt and (p in tables or c in tables):
            b.append(f'{p} -> {c} [dir=both arrowtail={tp} arrowhead={tc} color="{LINE}" penwidth=1.3];')
    if 'persona' in tables:
        b.append(f'persona:e -> persona:e [dir=both arrowtail=crowodot arrowhead=teeodot color="{LINE}" penwidth=1.2 '
                 f'label=<<FONT POINT-SIZE="8">id_persona_fusionada_en</FONT>>];')
    b += list(extra_rank)
    return graph(name, '\n '.join(b))


if __name__ == '__main__':
    render('Figura1_ER_General', er_general())
    render('Figura1A_ER_Abonados_y_personas', er_abonados())
    render('Figura1B_ER_Documentos', er_documentos())
    render('Figura1C_ER_Seguridad_bitacora_y_respaldos', er_seguridad())
    render('Figura2_Relacional_General', rel_general())
    render('Figura2A_Relacional_Abonados_y_personas',
           rel_detail('Rel_Abonados', ['sector', 'abonado', 'persona', 'vinculo_abonado'], [],
                      ['{rank=same; abonado; persona;}']))
    render('Figura2B_Relacional_Documentos',
           rel_detail('Rel_Documentos', ['grupo_alternativas', 'tipo_documento', 'documento', 'version_documento'],
                      ['abonado', 'persona'], ['{rank=same; tipo_documento; abonado; persona;}']))
    render('Figura2C_Relacional_Seguridad_bitacora_y_respaldos',
           rel_detail('Rel_Seguridad', ['cuenta', 'registro_bitacora', 'registro_modificacion', 'registro_restauracion',
                                        'respaldo', 'copia_respaldo'], [],
                      ['{rank=same; registro_bitacora; respaldo;}',
                       '{rank=same; registro_modificacion; registro_restauracion; copia_respaldo;}']))
    print('ok')


# ---------- Leyendas de 2.1 ----------
def legends():
    L = {}
    L['Leyenda_Entidad'] = graph('l1', f'e {entity("Entidad", ["atributo"])};', extra='pad=0.05;')
    L['Leyenda_Entidad_debil'] = graph('l2', f'e {entity("Entidad débil", [("clave_parcial", "partial")], weak=True)};', extra='pad=0.05;')
    L['Leyenda_Relacion'] = graph('l3', 'A [shape=box label="A" fontsize=10 width=0.6]; B [shape=box label="B" fontsize=10 width=0.6]; '
                                  + rel('A', 'B', 'teetee', 'crowodot', 'nombre'), rankdir='LR', extra='pad=0.05;')
    L['Leyenda_Identificadora'] = graph('l4', 'A [shape=box label="Fuerte" fontsize=10]; B [shape=box peripheries=2 label="Débil" fontsize=10]; '
                                        + rel('A', 'B', 'teetee', 'crowtee', 'contiene', ident=True), rankdir='LR', extra='pad=0.05;')
    card = []
    for i, (lab, h) in enumerate([('1..*', 'crowtee'), ('0..*', 'crowodot'), ('0..1', 'teeodot'), ('1', 'teetee')]):
        card += [f'a{i} [shape=plaintext label="{lab}" fontsize=10]; b{i} [shape=box label="X" fontsize=9 width=0.3 height=0.25];',
                 f'a{i} -> b{i} [arrowhead={h} color="{LINE}" penwidth=1.2 minlen=2];']
    L['Leyenda_Cardinalidad'] = graph('l5', '\n'.join(card), rankdir='LR', extra='pad=0.05; ranksep=0.2; nodesep=0.12;')
    L['Leyenda_MN'] = graph('l6', f'A [shape=box label="A" fontsize=10 width=0.6]; B [shape=box label="B" fontsize=10 width=0.6]; '
                            f'v [shape=diamond style=filled fillcolor="#DCE3ED" color="{LINE}" label=<<I>vínculo</I>> fontsize=9 width=1.0 height=0.45]; '
                            f'A -> v [dir=back arrowtail=crowtee color="{LINE}"]; v -> B [arrowhead=crowtee color="{LINE}"];', rankdir='LR', extra='pad=0.05;')
    L['Leyenda_Generalizacion'] = graph('l7', f'S [shape=box label="Supertipo" fontsize=10]; T1 [shape=box label="Subtipo1" fontsize=10]; '
                                        f'T2 [shape=box label="Subtipo2" fontsize=10]; T1 -> S [arrowhead=empty arrowsize=1.3 color="{LINE}"]; '
                                        f'T2 -> S [arrowhead=empty arrowsize=1.3 color="{LINE}"]; {{rank=same; T1; T2;}}', rankdir='BT', extra='pad=0.05; ranksep=0.4;')
    for k, v in L.items():
        render(k, v)


if __name__ == '__main__':
    legends()
